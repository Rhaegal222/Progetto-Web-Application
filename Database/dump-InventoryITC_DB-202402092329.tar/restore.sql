--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "InventoryITC_DB";
--
-- Name: InventoryITC_DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "InventoryITC_DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE "InventoryITC_DB" OWNER TO postgres;

\connect "InventoryITC_DB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employee_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_request (
    id_employee_request integer NOT NULL,
    requesting_user bigint,
    requested_item bigint,
    title character varying,
    description character varying,
    status character varying,
    type character varying,
    request_date character varying
);


ALTER TABLE public.employee_request OWNER TO postgres;

--
-- Name: employee_requests_id_employee_request_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_requests_id_employee_request_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_requests_id_employee_request_seq OWNER TO postgres;

--
-- Name: employee_requests_id_employee_request_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_requests_id_employee_request_seq OWNED BY public.employee_request.id_employee_request;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id_item integer NOT NULL,
    name character varying,
    type character varying,
    description character varying,
    location character varying,
    image_base64 text,
    assigned_user bigint
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: items_id_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.items_id_item_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.items_id_item_seq OWNER TO postgres;

--
-- Name: items_id_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.items_id_item_seq OWNED BY public.items.id_item;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id_user integer NOT NULL,
    password character varying,
    email character varying,
    name character varying,
    surname character varying,
    role character varying,
    banned boolean
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_user_seq OWNER TO postgres;

--
-- Name: users_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_user_seq OWNED BY public.users.id_user;


--
-- Name: employee_request id_employee_request; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_request ALTER COLUMN id_employee_request SET DEFAULT nextval('public.employee_requests_id_employee_request_seq'::regclass);


--
-- Name: items id_item; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items ALTER COLUMN id_item SET DEFAULT nextval('public.items_id_item_seq'::regclass);


--
-- Name: users id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id_user SET DEFAULT nextval('public.users_id_user_seq'::regclass);


--
-- Data for Name: employee_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_request (id_employee_request, requesting_user, requested_item, title, description, status, type, request_date) FROM stdin;
\.
COPY public.employee_request (id_employee_request, requesting_user, requested_item, title, description, status, type, request_date) FROM '$$PATH$$/4858.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id_item, name, type, description, location, image_base64, assigned_user) FROM stdin;
\.
COPY public.items (id_item, name, type, description, location, image_base64, assigned_user) FROM '$$PATH$$/4856.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id_user, password, email, name, surname, role, banned) FROM stdin;
\.
COPY public.users (id_user, password, email, name, surname, role, banned) FROM '$$PATH$$/4854.dat';

--
-- Name: employee_requests_id_employee_request_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_requests_id_employee_request_seq', 1, true);


--
-- Name: items_id_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.items_id_item_seq', 3, true);


--
-- Name: users_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_user_seq', 11, true);


--
-- Name: employee_request employee_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_request
    ADD CONSTRAINT employee_requests_pkey PRIMARY KEY (id_employee_request);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id_item);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_user);


--
-- Name: employee_request employee_requests_requested_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_request
    ADD CONSTRAINT employee_requests_requested_item_fkey FOREIGN KEY (requested_item) REFERENCES public.items(id_item);


--
-- Name: employee_request employee_requests_requesting_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_request
    ADD CONSTRAINT employee_requests_requesting_user_fkey FOREIGN KEY (requesting_user) REFERENCES public.users(id_user);


--
-- Name: items items_assigned_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_assigned_user_fkey FOREIGN KEY (assigned_user) REFERENCES public.users(id_user);


--
-- PostgreSQL database dump complete
--

